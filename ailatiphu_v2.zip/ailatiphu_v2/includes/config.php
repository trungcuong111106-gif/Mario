<?php
define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'game_ailatiphu');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=".DB_HOST.";port=".DB_PORT.";dbname=".DB_NAME.";charset=".DB_CHARSET;
        $options = [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false];
        try { $pdo = new PDO($dsn, DB_USER, DB_PASS, $options); }
        catch (PDOException $e) { die(json_encode(['error'=>'Kết nối CSDL thất bại: '.$e->getMessage()])); }
    }
    return $pdo;
}
session_start();
function isLoggedIn() { return isset($_SESSION['user_id']); }
function getCurrentUser() {
    if (!isLoggedIn()) return null;
    try {
        $db = getDB();
        $stmt = $db->prepare("SELECT id,hoten,email,sodt FROM taikhoan WHERE id=?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
        return ($user && is_array($user)) ? $user : null;
    } catch (Exception $e) { return null; }
}
// Auto-grant revive nếu user chưa có record
function ensureUserRevive($user_id) {
    try {
        $db = getDB();
        $db->prepare("INSERT IGNORE INTO user_items (taikhoan_id,item_type,so_luong) VALUES (?,?,?)")
           ->execute([$user_id,'revive',2]);
    } catch (Exception $e) {}
}
function redirect($url) { header("Location: $url"); exit; }
function getPrizeLadder() {
    return [
        1=>['prize'=>'1.000.000 đ','safe'=>false],2=>['prize'=>'2.000.000 đ','safe'=>false],
        3=>['prize'=>'3.000.000 đ','safe'=>false],4=>['prize'=>'5.000.000 đ','safe'=>false],
        5=>['prize'=>'10.000.000 đ','safe'=>true],6=>['prize'=>'20.000.000 đ','safe'=>false],
        7=>['prize'=>'40.000.000 đ','safe'=>false],8=>['prize'=>'80.000.000 đ','safe'=>false],
        9=>['prize'=>'160.000.000 đ','safe'=>false],10=>['prize'=>'320.000.000 đ','safe'=>true],
        11=>['prize'=>'640.000.000 đ','safe'=>false],12=>['prize'=>'1.250.000.000 đ','safe'=>false],
        13=>['prize'=>'2.500.000.000 đ','safe'=>false],14=>['prize'=>'5.000.000.000 đ','safe'=>false],
        15=>['prize'=>'10.000.000.000 đ','safe'=>true],
    ];
}
// Get user revive count
function getUserRevives($user_id) {
    $db = getDB();
    try {
        $stmt = $db->prepare("SELECT so_luong FROM user_items WHERE taikhoan_id=? AND item_type='revive'");
        $stmt->execute([$user_id]);
        $row = $stmt->fetch();
        return $row ? (int)$row['so_luong'] : 2; // default 2 free revives
    } catch (Exception $e) { return 1; }
}
