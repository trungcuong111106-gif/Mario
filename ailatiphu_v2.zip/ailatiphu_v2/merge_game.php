<?php
require_once 'includes/config.php';
if (!isLoggedIn()) redirect('auth.php');
$user = getCurrentUser();
if (!$user || !is_array($user)) { session_destroy(); redirect('auth.php'); }
$db = getDB();
$merge_best = 0; $merge_tile = 0;
try {
    $ms=$db->prepare("SELECT best_score,best_tile FROM merge_leaderboard WHERE taikhoan_id=?");
    $ms->execute([$user['id']]); $mr=$ms->fetch();
    $merge_best=$mr?(int)$mr['best_score']:0; $merge_tile=$mr?(int)$mr['best_tile']:0;
} catch(Exception $e){}
$lb_merge=[];
try { $lb_merge=$db->query("SELECT t.hoten,m.best_score,m.best_tile FROM merge_leaderboard m JOIN taikhoan t ON m.taikhoan_id=t.id ORDER BY m.best_score DESC LIMIT 8")->fetchAll(); } catch(Exception $e){}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=no">
<title>Merge 2048 – Ai Là Tỉ Phú</title>
<link href="https://fonts.googleapis.com/css2?family=Cinzel+Decorative:wght@700;900&family=Rajdhani:wght@400;600;700&family=Orbitron:wght@400;700;900&display=swap" rel="stylesheet">
<style>
:root{--dark:#0a0612;--pu:#7c3aed;--pu2:#a78bfa;}
*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent;}
body{font-family:'Rajdhani',sans-serif;background:var(--dark);min-height:100vh;color:#fff;overflow-x:hidden;}
.bg-fx{position:fixed;inset:0;z-index:0;background:radial-gradient(ellipse at 20% 30%,rgba(124,58,237,.15) 0%,transparent 55%),radial-gradient(ellipse at 80% 70%,rgba(167,139,250,.08) 0%,transparent 55%),var(--dark);}
.stars{position:fixed;inset:0;z-index:0;overflow:hidden;}
.star{position:absolute;background:#fff;border-radius:50%;animation:tw var(--d) ease-in-out infinite alternate;}
@keyframes tw{from{opacity:.04}to{opacity:.6}}
header{position:sticky;top:0;z-index:100;background:rgba(124,58,237,.08);border-bottom:1px solid rgba(124,58,237,.2);padding:11px 20px;display:flex;align-items:center;justify-content:space-between;backdrop-filter:blur(12px);}
.logo{font-family:'Cinzel Decorative',serif;font-size:.9rem;background:linear-gradient(135deg,#a78bfa,#7c3aed);-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
.btn-back{font-family:'Orbitron',sans-serif;font-size:.5rem;letter-spacing:1px;color:rgba(167,139,250,.7);text-decoration:none;border:1px solid rgba(124,58,237,.3);border-radius:20px;padding:6px 13px;transition:all .3s;}
.btn-back:hover{border-color:#a78bfa;color:#a78bfa;}
.game-wrap{position:relative;z-index:10;max-width:960px;margin:0 auto;padding:16px 14px;display:grid;grid-template-columns:1fr 220px;gap:18px;align-items:start;}
@media(max-width:640px){.game-wrap{grid-template-columns:1fr;}}
/* Score */
.score-row{display:flex;gap:9px;margin-bottom:13px;flex-wrap:wrap;}
.score-box{flex:1;min-width:80px;background:rgba(124,58,237,.12);border:1px solid rgba(124,58,237,.25);border-radius:11px;padding:9px 12px;text-align:center;}
.score-label{font-family:'Orbitron',sans-serif;font-size:.47rem;letter-spacing:2px;color:rgba(167,139,250,.6);margin-bottom:3px;}
.score-val{font-family:'Orbitron',sans-serif;font-size:1.2rem;font-weight:900;color:#a78bfa;}
.score-val.gold{color:#FFD700;}
.board-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:11px;}
.game-title{font-family:'Cinzel Decorative',serif;font-size:1.25rem;background:linear-gradient(135deg,#a78bfa,#7c3aed);-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
.btn-new{font-family:'Orbitron',sans-serif;font-size:.52rem;letter-spacing:1px;background:linear-gradient(135deg,#7c3aed,#a78bfa);border:none;border-radius:9px;padding:8px 15px;color:#fff;cursor:pointer;transition:all .3s;}
.btn-new:hover{transform:translateY(-2px);box-shadow:0 5px 18px rgba(124,58,237,.4);}
/* Board */
.board-outer{position:relative;}
#board{
  display:grid;grid-template-columns:repeat(4,1fr);grid-template-rows:repeat(4,1fr);
  gap:10px;background:rgba(124,58,237,.15);border:1px solid rgba(124,58,237,.25);
  border-radius:16px;padding:10px;
  width:min(400px,calc(100vw - 28px));height:min(400px,calc(100vw - 28px));
  cursor:grab;user-select:none;touch-action:none;
}
#board:active{cursor:grabbing;}
.cell{border-radius:10px;display:flex;align-items:center;justify-content:center;
  font-family:'Orbitron',sans-serif;font-weight:900;user-select:none;transition:transform .08s;}
.cell.empty{background:rgba(255,255,255,.04);}
.cell.new-tile{animation:tileNew .18s ease;}
.cell.merge-tile{animation:tileMerge .18s ease;}
@keyframes tileNew{from{transform:scale(0)}to{transform:scale(1)}}
@keyframes tileMerge{0%{transform:scale(1)}50%{transform:scale(1.15)}100%{transform:scale(1)}}
.t2{background:linear-gradient(135deg,#e0d8f0,#c4b5fd);color:#1a0f2e;font-size:clamp(1.1rem,4.5vw,1.55rem);}
.t4{background:linear-gradient(135deg,#c4b5fd,#a78bfa);color:#1a0f2e;font-size:clamp(1.1rem,4.5vw,1.55rem);}
.t8{background:linear-gradient(135deg,#a78bfa,#7c3aed);color:#fff;font-size:clamp(1rem,4vw,1.45rem);}
.t16{background:linear-gradient(135deg,#7c3aed,#6d28d9);color:#fff;font-size:clamp(1rem,4vw,1.35rem);}
.t32{background:linear-gradient(135deg,#f59e0b,#d97706);color:#fff;font-size:clamp(.95rem,3.5vw,1.25rem);}
.t64{background:linear-gradient(135deg,#f97316,#ea580c);color:#fff;font-size:clamp(.9rem,3.2vw,1.2rem);}
.t128{background:linear-gradient(135deg,#ef4444,#dc2626);color:#fff;font-size:clamp(.8rem,3vw,1.1rem);}
.t256{background:linear-gradient(135deg,#ec4899,#db2777);color:#fff;font-size:clamp(.75rem,2.7vw,1rem);}
.t512{background:linear-gradient(135deg,#14b8a6,#0d9488);color:#fff;font-size:clamp(.7rem,2.5vw,.95rem);}
.t1024{background:linear-gradient(135deg,#22c55e,#16a34a);color:#fff;font-size:clamp(.62rem,2.2vw,.88rem);}
.t2048{background:linear-gradient(135deg,#FFD700,#FFA500);color:#0a0612;font-size:clamp(.58rem,2vw,.82rem);box-shadow:0 0 28px rgba(255,215,0,.6);}
.t4096{background:linear-gradient(135deg,#fff176,#fff);color:#0a0612;font-size:clamp(.54rem,1.8vw,.76rem);box-shadow:0 0 28px rgba(255,255,255,.5);}
/* Overlay */
.board-overlay{position:absolute;inset:0;background:rgba(10,6,18,.9);border-radius:16px;
  display:flex;flex-direction:column;align-items:center;justify-content:center;
  z-index:10;opacity:0;pointer-events:none;transition:opacity .4s;backdrop-filter:blur(8px);}
.board-overlay.show{opacity:1;pointer-events:all;}
.ov-title{font-family:'Cinzel Decorative',serif;font-size:1.4rem;margin-bottom:7px;}
.ov-score{font-family:'Orbitron',sans-serif;font-size:.82rem;color:#FFD700;margin-bottom:5px;}
.ov-best{font-family:'Orbitron',sans-serif;font-size:.62rem;color:rgba(255,215,0,.5);margin-bottom:18px;}
/* Controls */
.ctrl-wrap{margin-top:12px;display:grid;grid-template-columns:1fr 1fr;gap:10px;}
.ctrl-panel{background:rgba(124,58,237,.08);border:1px solid rgba(124,58,237,.2);border-radius:12px;padding:12px 14px;}
.ctrl-head{font-family:'Orbitron',sans-serif;font-size:.5rem;letter-spacing:2px;color:rgba(167,139,250,.6);margin-bottom:10px;}
/* D-PAD */
.dpad{display:grid;grid-template-columns:repeat(3,40px);grid-template-rows:repeat(3,40px);gap:4px;margin:0 auto;width:fit-content;}
.dpad-btn{background:rgba(124,58,237,.18);border:1px solid rgba(124,58,237,.4);border-radius:9px;
  display:flex;align-items:center;justify-content:center;font-size:1rem;cursor:pointer;
  color:#a78bfa;transition:all .15s;user-select:none;}
.dpad-btn:hover{background:rgba(124,58,237,.4);transform:scale(1.07);}
.dpad-btn:active,.dpad-btn.pressed{background:rgba(124,58,237,.72);transform:scale(.92);box-shadow:0 0 14px rgba(124,58,237,.55);}
.dpad-center{background:rgba(124,58,237,.06);cursor:default;font-size:.42rem;font-family:'Orbitron',sans-serif;color:rgba(167,139,250,.3);letter-spacing:1px;}
.dpad-empty{visibility:hidden;}
/* Hint rows */
.hint-list{display:flex;flex-direction:column;gap:7px;}
.hint-item{display:flex;align-items:center;gap:9px;padding:6px 8px;
  background:rgba(124,58,237,.06);border:1px solid rgba(124,58,237,.15);border-radius:8px;}
.hint-icon{font-size:1rem;flex-shrink:0;width:22px;text-align:center;}
.hint-txt{font-size:.73rem;color:rgba(255,255,255,.5);line-height:1.3;}
.hint-txt b{color:rgba(167,139,250,.9);}
/* Sidebar */
.sidebar{min-width:200px;}
@media(max-width:640px){.sidebar{min-width:100%;}}
.panel{background:rgba(124,58,237,.06);border:1px solid rgba(124,58,237,.2);border-radius:13px;padding:15px;margin-bottom:13px;}
.panel-title{font-family:'Orbitron',sans-serif;font-size:.57rem;letter-spacing:3px;color:rgba(167,139,250,.6);margin-bottom:11px;}
.lb-row{display:flex;align-items:center;gap:8px;padding:5px 0;border-bottom:1px solid rgba(255,255,255,.04);font-size:.8rem;}
.lb-row:last-child{border:none;}
.lb-rank{font-family:'Orbitron',sans-serif;font-size:.68rem;font-weight:900;width:20px;text-align:center;}
.r1{color:#FFD700}.r2{color:#C0C0C0}.r3{color:#CD7F32}
.lb-name{flex:1;font-weight:600;font-size:.82rem;}
.lb-score{font-family:'Orbitron',sans-serif;font-size:.56rem;color:#a78bfa;}
.lb-tile{font-size:.66rem;margin-left:3px;}
.how-item{display:flex;gap:8px;padding:5px 0;border-bottom:1px solid rgba(255,255,255,.04);}
.how-item:last-child{border:none;}
.how-icon{font-size:.9rem;width:22px;text-align:center;}
.how-text{font-size:.75rem;color:rgba(255,255,255,.45);line-height:1.4;}
</style>
</head>
<body>
<div class="bg-fx"></div><div class="stars" id="stars"></div>
<header>
  <div class="logo">🔢 Merge 2048</div>
  <a href="index.php" class="btn-back">← TRANG CHỦ</a>
</header>

<div class="game-wrap">
  <!-- LEFT: GAME -->
  <div>
    <div class="score-row">
      <div class="score-box"><div class="score-label">ĐIỂM</div><div class="score-val" id="scoreVal">0</div></div>
      <div class="score-box"><div class="score-label">KỶ LỤC</div><div class="score-val gold" id="bestVal"><?= number_format($merge_best) ?></div></div>
      <div class="score-box"><div class="score-label">Ô CAO NHẤT</div><div class="score-val" id="tileVal"><?= $merge_tile ?: '-' ?></div></div>
    </div>
    <div class="board-header">
      <div class="game-title">2048</div>
      <button class="btn-new" onclick="newGame()">🔄 VÁN MỚI</button>
    </div>
    <div class="board-outer">
      <div id="board"></div>
      <div class="board-overlay" id="boardOverlay">
        <div class="ov-title" id="ovTitle">GAME OVER</div>
        <div class="ov-score" id="ovScore"></div>
        <div class="ov-best" id="ovBest"></div>
        <button class="btn-new" onclick="newGame()" style="margin-top:8px">🔄 CHƠI LẠI</button>
      </div>
    </div>

    <!-- Controls: D-Pad + Hints -->
    <div class="ctrl-wrap">
      <div class="ctrl-panel">
        <div class="ctrl-head">🎮 NÚT ĐIỀU KHIỂN</div>
        <div class="dpad">
          <div class="dpad-empty"></div>
          <div class="dpad-btn" id="dUp"    onmousedown="move('up')"    ontouchstart="moveTap('up',$event)">↑</div>
          <div class="dpad-empty"></div>
          <div class="dpad-btn" id="dLeft"  onmousedown="move('left')"  ontouchstart="moveTap('left',$event)">←</div>
          <div class="dpad-btn dpad-center">2048</div>
          <div class="dpad-btn" id="dRight" onmousedown="move('right')" ontouchstart="moveTap('right',$event)">→</div>
          <div class="dpad-empty"></div>
          <div class="dpad-btn" id="dDown"  onmousedown="move('down')"  ontouchstart="moveTap('down',$event)">↓</div>
          <div class="dpad-empty"></div>
        </div>
      </div>
      <div class="ctrl-panel">
        <div class="ctrl-head">📋 ĐIỀU KHIỂN</div>
        <div class="hint-list">
          <div class="hint-item"><span class="hint-icon">⌨️</span><span class="hint-txt"><b>Phím mũi tên</b> hoặc <b>W A S D</b></span></div>
          <div class="hint-item"><span class="hint-icon">🖱️</span><span class="hint-txt"><b>Kéo chuột</b> trên bảng game</span></div>
          <div class="hint-item"><span class="hint-icon">📱</span><span class="hint-txt"><b>Vuốt tay</b> trên màn hình</span></div>
          <div class="hint-item"><span class="hint-icon">🎮</span><span class="hint-txt"><b>Click nút</b> D-Pad bên trái</span></div>
        </div>
      </div>
    </div>
  </div>

  <!-- RIGHT: SIDEBAR -->
  <div class="sidebar">
    <div class="panel">
      <div class="panel-title">🏆 BẢNG XẾP HẠNG</div>
      <?php if(empty($lb_merge)):?>
        <p style="color:rgba(255,255,255,.3);font-size:.78rem;text-align:center;padding:10px">Chưa có ai chơi!</p>
      <?php else: foreach($lb_merge as $i=>$row): $rank=$i+1;?>
        <div class="lb-row">
          <div class="lb-rank <?=$rank<=3?'r'.$rank:''?>"><?=['🥇','🥈','🥉'][$i]??$rank?></div>
          <div class="lb-name"><?=htmlspecialchars($row['hoten'])?></div>
          <div class="lb-score"><?=number_format($row['best_score'])?></div>
          <div class="lb-tile"><?=$row['best_tile']>0?'['.$row['best_tile'].']':''?></div>
        </div>
      <?php endforeach; endif;?>
    </div>
    <div class="panel">
      <div class="panel-title">📖 LUẬT CHƠI</div>
      <div class="how-item"><div class="how-icon">🎯</div><div class="how-text">Gộp ô số giống nhau tạo số lớn hơn</div></div>
      <div class="how-item"><div class="how-icon">🔢</div><div class="how-text">Đạt ô <b style="color:#FFD700">2048</b> để chiến thắng</div></div>
      <div class="how-item"><div class="how-icon">💾</div><div class="how-text">Điểm cao <b>tự động lưu</b></div></div>
      <div class="how-item"><div class="how-icon">💀</div><div class="how-text">Thua khi không còn nước đi</div></div>
    </div>
  </div>
</div>

<script>
const SIZE=4;
let board=[],score=0,bestScore=<?=(int)$merge_best?>,gameOver=false,won=false,saveTimer=null;

function newGame(){
  board=Array.from({length:SIZE},()=>Array(SIZE).fill(0));
  score=0;gameOver=false;won=false;
  addTile();addTile();render();
  document.getElementById('boardOverlay').classList.remove('show');
}
function addTile(){
  const empty=[];
  for(let r=0;r<SIZE;r++)for(let c=0;c<SIZE;c++)if(!board[r][c])empty.push([r,c]);
  if(!empty.length)return;
  const[r,c]=empty[Math.floor(Math.random()*empty.length)];
  board[r][c]=Math.random()<.9?2:4;
}
function slideRow(row){
  let arr=row.filter(x=>x),merged=[];
  while(arr.length){
    if(arr.length>1&&arr[0]===arr[1]){
      const v=arr[0]*2;merged.push(v);score+=v;if(v>bestScore)bestScore=v;arr=arr.slice(2);
    }else{merged.push(arr[0]);arr=arr.slice(1);}
  }
  while(merged.length<SIZE)merged.push(0);
  return merged;
}
function move(dir){
  if(gameOver&&!won)return;
  const prev=JSON.stringify(board);
  if(dir==='left')board=board.map(r=>slideRow(r));
  else if(dir==='right')board=board.map(r=>slideRow([...r].reverse()).reverse());
  else if(dir==='up'){for(let c=0;c<SIZE;c++){let col=board.map(r=>r[c]);col=slideRow(col);for(let r=0;r<SIZE;r++)board[r][c]=col[r];}}
  else if(dir==='down'){for(let c=0;c<SIZE;c++){let col=board.map(r=>r[c]).reverse();col=slideRow(col).reverse();for(let r=0;r<SIZE;r++)board[r][c]=col[r];}}
  if(JSON.stringify(board)!==prev){addTile();render();debounceSave();checkEnd();}
  // Flash D-pad
  const btnId={up:'dUp',down:'dDown',left:'dLeft',right:'dRight'}[dir];
  const btn=document.getElementById(btnId);
  if(btn){btn.classList.add('pressed');setTimeout(()=>btn.classList.remove('pressed'),160);}
}
function moveTap(dir,e){e.preventDefault();move(dir);}
function checkEnd(){
  const flat=board.flat();
  if(flat.includes(2048)&&!won){won=true;showOv('🏆 ĐẠT 2048!','#FFD700');return;}
  for(let r=0;r<SIZE;r++)for(let c=0;c<SIZE;c++){
    if(!board[r][c])return;
    if(r<SIZE-1&&board[r][c]===board[r+1][c])return;
    if(c<SIZE-1&&board[r][c]===board[r][c+1])return;
  }
  gameOver=true;showOv('💀 GAME OVER','#ff4757');
}
function showOv(title,color){
  const ov=document.getElementById('boardOverlay');
  document.getElementById('ovTitle').textContent=title;
  document.getElementById('ovTitle').style.color=color;
  document.getElementById('ovScore').textContent='Điểm: '+score.toLocaleString();
  document.getElementById('ovBest').textContent='Kỷ lục: '+bestScore.toLocaleString();
  ov.classList.add('show');
}
const TC={2:'t2',4:'t4',8:'t8',16:'t16',32:'t32',64:'t64',128:'t128',256:'t256',512:'t512',1024:'t1024',2048:'t2048',4096:'t4096'};
function render(){
  const el=document.getElementById('board');el.innerHTML='';
  for(let r=0;r<SIZE;r++)for(let c=0;c<SIZE;c++){
    const v=board[r][c],cell=document.createElement('div');
    cell.className='cell '+(v?TC[v]||'t4096':'empty');
    if(v)cell.textContent=v;
    el.appendChild(cell);
  }
  document.getElementById('scoreVal').textContent=score.toLocaleString();
  document.getElementById('bestVal').textContent=bestScore.toLocaleString();
  const mx=Math.max(...board.flat());
  document.getElementById('tileVal').textContent=mx>0?mx:'-';
}
function debounceSave(){
  clearTimeout(saveTimer);
  saveTimer=setTimeout(()=>{
    fetch('save_merge.php',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({score,best_tile:Math.max(...board.flat())})});
  },700);
}

// ===== KEYBOARD =====
document.addEventListener('keydown',e=>{
  const m={'ArrowUp':'up','ArrowDown':'down','ArrowLeft':'left','ArrowRight':'right',
           'w':'up','s':'down','a':'left','d':'right',
           'W':'up','S':'down','A':'left','D':'right'};
  if(m[e.key]){e.preventDefault();move(m[e.key]);}
});
window.addEventListener('keydown',e=>{
  if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight',' '].includes(e.key))e.preventDefault();
},{passive:false});

// ===== MOUSE DRAG on board =====
const boardEl=document.getElementById('board');
let md=false,mx0=0,my0=0;
const MIN=30;
boardEl.addEventListener('mousedown',e=>{md=true;mx0=e.clientX;my0=e.clientY;e.preventDefault();},{passive:false});
document.addEventListener('mouseup',e=>{
  if(!md)return;md=false;
  const dx=e.clientX-mx0,dy=e.clientY-my0;
  if(Math.abs(dx)>=MIN||Math.abs(dy)>=MIN){
    if(Math.abs(dx)>Math.abs(dy))move(dx>0?'right':'left');
    else move(dy>0?'down':'up');
  }
});

// ===== TOUCH SWIPE =====
let tx0=0,ty0=0;
boardEl.addEventListener('touchstart',e=>{tx0=e.touches[0].clientX;ty0=e.touches[0].clientY;},{passive:true});
boardEl.addEventListener('touchend',e=>{
  const dx=e.changedTouches[0].clientX-tx0,dy=e.changedTouches[0].clientY-ty0;
  if(Math.abs(dx)>=MIN||Math.abs(dy)>=MIN){
    if(Math.abs(dx)>Math.abs(dy))move(dx>0?'right':'left');
    else move(dy>0?'down':'up');
  }
},{passive:true});

// ===== STARS =====
const s=document.getElementById('stars');
for(let i=0;i<80;i++){
  const el=document.createElement('div');el.className='star';
  const sz=Math.random()*2+.4;
  el.style.cssText=`width:${sz}px;height:${sz}px;left:${Math.random()*100}%;top:${Math.random()*100}%;--d:${2+Math.random()*5}s;animation-delay:${Math.random()*5}s`;
  s.appendChild(el);
}
newGame();
</script>
</body>
</html>
