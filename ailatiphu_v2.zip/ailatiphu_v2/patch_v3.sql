-- ============================================================
-- PATCH V3: Thêm 4 chủ đề mới + nâng revive 2 lần/ngày
-- Chạy sau patch_v2.sql
-- ============================================================
USE `game_ailatiphu`;

-- 1. Thêm 4 chủ đề mới
INSERT IGNORE INTO `linhvuc` (`id`,`tenlinhvuc`,`icon`,`mota`) VALUES
(9,'Thiên văn học','🔭','Vũ trụ • Hành tinh • Ngôi sao • Thiên hà'),
(10,'Phim ảnh','🎬','Phim Hollywood • Anime • Đạo diễn • Diễn viên'),
(11,'Động vật','🦁','Thú • Chim • Bò sát • Đại dương'),
(12,'Thần thoại','⚡','Thần thoại Hy Lạp • La Mã • Norse • Á Đông');

-- 2. Nâng revive lên 2 lần/ngày
UPDATE `user_items` SET `so_luong`=2 WHERE `item_type`='revive' AND `so_luong`<=1;

-- 3. Câu hỏi sẽ được IMPORT qua file patch_v3_questions.sql riêng
-- (do file quá lớn, chia thành 2 file)
-- Xem file: patch_v3_questions.sql

COMMIT;
